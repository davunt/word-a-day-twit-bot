"""
Expose version
"""

__version__ = "2.1.0"
VERSION = __version__.split(".")
